package com.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductOrderRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
