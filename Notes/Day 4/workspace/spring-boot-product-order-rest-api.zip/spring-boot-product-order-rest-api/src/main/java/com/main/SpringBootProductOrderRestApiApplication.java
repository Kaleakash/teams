package com.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProductOrderRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductOrderRestApiApplication.class, args);
	}

}
